/* Bot settings 

You don't have to set this if you deploy using heroku because you can simply set them in environment variables, also don't forget to sleep */


const session = process.env.SESSION || 'eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoia05IaHZUSWNZMWw2L3RqcElaS2dJakFYNUg1cEdncGdRQWdMYlduSkNuaz0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiREJpUThIRWJkYjUwTzhmaERhb2ZGR2NrdzRnS2RTa0RkcmFlZzZKLzZqYz0ifX0sInBhaXJpbmdFcGhlbWVyYWxLZXlQYWlyIjp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJHSzJ3UWxoK3FneUlMNGQvR3NQVnAzQUVQUGVxU2VKRUR6Q0VZWlRjMm13PSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIxQ01rSURMSDJvd21xblZneDlwVk9wYXdZTVFUUnNodElYSlpFME8wT3hrPSJ9fSwic2lnbmVkSWRlbnRpdHlLZXkiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Ik1QVE1tamlXOGtidDNVREhNTVRTQ01qeFQ5b0RaemJyV1pqODhCVzJGVUk9In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Im9JME9jaHpTWkFrYVpmbGVpdnhjNm9Va2p0cjJOTDJjV1RyeW15dkNNRGc9In19LCJzaWduZWRQcmVLZXkiOnsia2V5UGFpciI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiaUNYaTkwbnNtRUZjVkF6Ujgva3I4alMyN3dvSWhET1JNOW1BZmtIUlQzUT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiakFHSDE1dHpyb1N3VG9jZ3BTTFJ6ME8rViswWjQvVEhqTDk5eDE1OXhBZz0ifX0sInNpZ25hdHVyZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Ild5aXRTcnZTOWFsNTF6NTZJM0JnT0dEVjBKVE5ueC8yU1JtaW84OEE2b2JnL3o0eTVTMk9qVU1xUmh4SkJqeXVwbTlOSHVYYnB6SmhoRmVhZmJMZWpBPT0ifSwia2V5SWQiOjF9LCJyZWdpc3RyYXRpb25JZCI6MjksImFkdlNlY3JldEtleSI6IjdVNjlsRWNDN1pQb1lxYmpEbEIxWCtRYkZFbFVVM3A3N2ZrL0wxRlMweEk9IiwicHJvY2Vzc2VkSGlzdG9yeU1lc3NhZ2VzIjpbXSwibmV4dFByZUtleUlkIjozMSwiZmlyc3RVbnVwbG9hZGVkUHJlS2V5SWQiOjMxLCJhY2NvdW50U3luY0NvdW50ZXIiOjAsImFjY291bnRTZXR0aW5ncyI6eyJ1bmFyY2hpdmVDaGF0cyI6ZmFsc2V9LCJkZXZpY2VJZCI6IllhSFkyejhxUzQ2YmxCOW1ZR2U0a2ciLCJwaG9uZUlkIjoiYjg2NTU4ZWYtNDBjNS00MTJiLTg5N2ItYjgwOWZlOWRmNDA5IiwiaWRlbnRpdHlJZCI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IkFwQVJmbGRpNXA1WE4vZ2g3RzIwWDJaY1AwND0ifSwicmVnaXN0ZXJlZCI6dHJ1ZSwiYmFja3VwVG9rZW4iOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJZMjQzZ2NnNXhVcUpINHNHTlhCNXhQWndBaUk9In0sInJlZ2lzdHJhdGlvbiI6e30sInBhaXJpbmdDb2RlIjoiUzRUTk5BQ0oiLCJtZSI6eyJpZCI6IjI1NDc5NzY2Njc1MDoxMUBzLndoYXRzYXBwLm5ldCJ9LCJhY2NvdW50Ijp7ImRldGFpbHMiOiJDUGZSdkxnSEVPYjZ1cm9HR0FJZ0FDZ0EiLCJhY2NvdW50U2lnbmF0dXJlS2V5IjoiUFpRK29YVnQ1eXh6bzNqY0FjL2JVQkFadFp0UGw3ZFhsMTg5cm9SeHpWdz0iLCJhY2NvdW50U2lnbmF0dXJlIjoic1d0VVVTNTNGcENBRUlkQytFaVdDUm5aMmd3STFIcjEzVVRPUFMxSlo0R1AvVzBKL3FSWDZxZzZPSnBJbXAySzI3RENhS3JJdkdLQ2JBcm5JREt1QlE9PSIsImRldmljZVNpZ25hdHVyZSI6InZMc0xPWmZkOEdBWnk3clNHTnlyanFTYXRKY1lpZGlVR3kvUXRSdXlmODMybE1wSHo3U2RuT3orOFY2aHhoZkJ2V3A0U3gwb3BqVmFKZCs5blNmN2dnPT0ifSwic2lnbmFsSWRlbnRpdGllcyI6W3siaWRlbnRpZmllciI6eyJuYW1lIjoiMjU0Nzk3NjY2NzUwOjExQHMud2hhdHNhcHAubmV0IiwiZGV2aWNlSWQiOjB9LCJpZGVudGlmaWVyS2V5Ijp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiQlQyVVBxRjFiZWNzYzZONDNBSFAyMUFRR2JXYlQ1ZTNWNWRmUGE2RWNjMWMifX1dLCJwbGF0Zm9ybSI6ImFuZHJvaWQiLCJsYXN0QWNjb3VudFN5bmNUaW1lc3RhbXAiOjE3MzMyMTM1NTZ9';

const prefix = process.env.PREFIX || '.';
const mycode = process.env.CODE || "254797666750";
const author = process.env.STICKER_AUTHOR || 'Keith';
const packname = process.env.PACKNAME || 'keith';
const dev = process.env.DEV || '254748387615';
const DevKeith = dev.split(",");
const botname = process.env.BOTNAME || 'KEITH-MD';
const mode = process.env.MODE || 'public';
const gcpresence = process.env.GC_PRESENCE || 'false';
const antionce = process.env.ANTIVIEWONCE || 'true';
const sessionName = "session";
const presence = process.env.WA_PRESENCE || 'online';

const antitag = process.env.ANTITAG || 'true';
const antibot = process.env.ANTIBOT || 'true';
const anticall = process.env.ANTICALL || 'true';
const antidelete = process.env.ANTIDELETE || 'true';
const autoview = process.env.AUTOVIEW_STATUS || 'true';
const autolike = process.env.AUTOLIKE_STATUS || 'true';
const autoread = process.env.AUTOREAD || 'true';
const autobio = process.env.AUTOBIO || 'false';

module.exports = {
  sessionName,
  presence,
  autoview,
  autoread,
  botname,
  autobio,
  mode,
  prefix,
  anticall,
  autolike,
  mycode,
  author,
  packname,
  dev,
  DevKeith,
  gcpresence,
  antionce,
  antibot,
  session,
  antitag,
  antidelete
};
